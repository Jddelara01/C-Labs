//John Darren De Lara - X00072126	Lab4A

/*Reference:
https://www.geeksforgeeks.org/root-to-leaf-path-sum-equal-to-a-given-number/
https://www.geeksforgeeks.org/given-a-binary-tree-print-all-root-to-leaf-paths/
*/

#include <iostream>
#include <string>

using namespace std;

template <class T>
class BinarySearchTree {
private:
	struct treeNode {
		T data;
		treeNode *leftPtr;
		treeNode *rightPtr;
	};
	treeNode *root;

	typedef struct {
		int sum;
		bool found;
	} hasPathStruct;

	typedef struct {
		treeNode *root;
	} Tree;

	void addPrivate(T data, treeNode *nodePtr) {
		if (root == NULL)
		{
			root = CreateLeaf(data);
		}
		else if (data < nodePtr->data)
		{
			if (nodePtr->leftPtr != NULL) {
				addPrivate(data, nodePtr->leftPtr);
			}
			else
			{
				nodePtr->leftPtr = CreateLeaf(data);
			}
		}
		else if (data > nodePtr->data)
		{
			if (nodePtr->rightPtr != NULL) {
				addPrivate(data, nodePtr->rightPtr);
			}
			else
			{
				nodePtr->rightPtr = CreateLeaf(data);
			}
		}
		else
		{
			cout << "The data " << data << " has already been added to the tree" << endl;
		}

	}

	//use the method if the data type is char
	bool searchNode(T data, treeNode *tnPtr)
	{
		if (tnPtr->data == data)
		{
			cout << "true" << endl;
			return true;
		}
		else
		{
			cout << "false" << endl;
			return false;
		}

	}

	//to print all the tree values in ascending order
	//using a in-order traversal
	void printInOrder(treeNode *nodePtr)
	{
		if (root != NULL)
		{
			if (nodePtr->leftPtr != NULL)
			{
				printInOrder(nodePtr->leftPtr);
			}
			cout << nodePtr->data << " " << endl;
			if (nodePtr->rightPtr != NULL)
			{
				printInOrder(nodePtr->rightPtr);
			}
		}
		else
		{
			cout << "Tree is empty..." << endl;
		}
	}

	//Post order traversal
	void printPostOrder(treeNode *nodePtr)
	{
		if (nodePtr == NULL)
			return;

		//first recur on left subtree
		if (nodePtr->leftPtr != NULL)
		{
			printPostOrder(nodePtr->leftPtr);
		}
		//then recur on the right subtree
		if (nodePtr->rightPtr != NULL)
		{
			printPostOrder(nodePtr->rightPtr);
		}
		//now print the node
		cout << nodePtr->data << " " << endl;

	}

	//Pre order traversal
	void printPreOrder(treeNode *nodePtr)
	{
		if (nodePtr == NULL)
			return;

		//first print the data of node
		cout << nodePtr->data << " " << endl;

		//then recur on left subtree
		if (nodePtr->leftPtr != NULL)
		{
			printPreOrder(nodePtr->leftPtr);
		}

		//now recur on the right subtree
		if (nodePtr->rightPtr != NULL)
		{
			printPreOrder(nodePtr->rightPtr);
		}
	}

	/*hasPathStruct hasPath(treeNode *node, int sum)
	{
		hasPathStruct temp = { 0, false };
		if (node == 0)
			return temp;

		hasPathStruct temp_left = hasPath(node->left, sum);
		hasPathStruct temp_right = hasPath(node->right, sum);

		temp.sum = temp_left.sum + temp_right + node->data;
		temp.found = temp_left.found || temp_right.found || temp.sum == sum;

		return temp;
	}*/

public:
	BinarySearchTree() {
		root = NULL;
	}

	treeNode *CreateLeaf(T data)
	{
		treeNode *tn = new treeNode;
		tn->data = data;
		tn->leftPtr = NULL;
		tn->rightPtr = NULL;

		return tn;
	}

	void add(T data) {
		addPrivate(data, root);
	}

	//use the method if the data type is char
	bool searchNode(T data) {
		return searchNode(data, root);
	}

	//to print all the tree values in ascending order
	//it is using a in-order traversal
	void printInOrder() {
		printInOrder(root);
	}

	//to print all the tree values in ascending order
	//it is using a Pre-order traversal
	void printPreOrder() {
		printPreOrder(root);
	}
	//to print all the tree values in ascending order
	//it is using a Post-order traversal
	void printPostOrder() {
		printPostOrder(root);
	}
};

struct node
{
	int data;
	struct node* left;
	struct node* right;
};

/*
Given a tree and a sum, return true if there is a path from the root
down to a leaf, such that adding up all the values along the path
equals the given sum.

Strategy: subtract the node value from the sum when recurring down,
and check to see if the sum is 0 when you run out of tree.
*/
bool hasPathSum(struct node* node, int sum)
{
	/* return true if we run out of tree and sum==0 */
	if (node == NULL)
	{
		return (sum == 0);
	}

	else
	{
		bool ans = 0;

		/* otherwise check both subtrees */
		int subSum = sum - node->data;

		/* If we reach a leaf node and sum becomes 0 then return true*/
		if (subSum == 0 && node->left == NULL && node->right == NULL)
			return 1;

		// subtract the node value and continue visit two sub trees. 
		if (node->left)
			ans = ans || hasPathSum(node->left, subSum);
		if (node->right)
			ans = ans || hasPathSum(node->right, subSum);

		return ans;
	}
}

/* UTILITY FUNCTIONS */
/* Helper function that allocates a new node with the
given data and NULL left and right pointers. */
struct node* newnode(int data)
{
	struct node* node = (struct node*)
		malloc(sizeof(struct node));
	node->data = data;
	node->left = NULL;
	node->right = NULL;

	return(node);
}

//print function to print all  roo to leaf paths
void printArray(int nodes[], int lengthOfArray)
{

	for (int i = 0; i<lengthOfArray; i++)
	{
		cout << nodes[i] << endl;
	}
}

/* Recursive helper function -- given a node, and an array containing
the path from the root node up to but not including this node,
print out all the root-leaf paths.*/
void printPathsRecur(struct node* node, int path[], int pathLen)
{
	if (node == NULL)
		return;

	/* append this node to the path array */
	path[pathLen] = node->data;
	pathLen++;

	/* it's a leaf, so print the path that led to here  */
	if (node->left == NULL && node->right == NULL)
	{
		printArray(path, pathLen);
	}
	else
	{
		/* otherwise try both subtrees */
		printPathsRecur(node->left, path, pathLen);
		printPathsRecur(node->right, path, pathLen);
	}
}

void printPaths(struct node* node)
{
	int path[1000];
	printPathsRecur(node, path, 0);
}

int main() {
	char treeData[5] = { 'g', 'a', 'z', 'b', 'y' };
	BinarySearchTree<char> bst;

	for (int i = 0; i < 5; i++) {
		bst.add(treeData[i]);
	}

	cout << "In-order traversal" << endl;
	bst.printInOrder();
	cout << " " << endl;

	cout << "Pre-order traversal" << endl;
	bst.printPreOrder();
	cout << " " << endl;

	cout << "Post-order traversal" << endl;
	bst.printPostOrder();
	cout << " " << endl;

	cout << "testing hasPathSum function..." << endl;

	int sum[5] = { 27, 22, 26, 18, 14 };

	
	struct node *root = newnode(5);
	root->left = newnode(4);
	root->right = newnode(8);
	root->left->left = newnode(11);
	root->left->left->left = newnode(7);
	root->left->left->right = newnode(2);
	root->right->left = newnode(13);
	root->right->right = newnode(4);
	root->right->right->right = newnode(1);
	
	for (int i = 0; i < 5; i++) {
		if (hasPathSum(root, sum[i])) {
			cout << "The sum " << sum[i] << " has a root to leaf path" << endl;
		}
		else
		{
			cout << "The sum " << sum[i] << " has NO root to leaf path" << endl;
		}
	}
	
	//print all the root to leaf paths
	printPaths(root);

	system("pause");
	return 0;
}